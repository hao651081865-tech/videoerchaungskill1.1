---
name: video-remake-adapter
description: End-to-end video reverse-prompt, asset locking, storyboard prompt, API video generation, and remake/adaptation workflow. Use when the user provides or references a video and asks to reverse engineer prompts, infer video prompts, analyze subject/action/scene/lighting/camera/style/quality, remake or adapt a video, replace characters/scenes/props/dialogue, create new image assets first, confirm assets before video generation, or produce organized AI short-video deliverables.
---

# Video Remake Adapter

Use this skill to turn a reference video into a new production package and final generated video clips. Preserve the source video's content unless the user explicitly asks for a change. Do not self-adapt, extend, compress, add, remove, or reinterpret story content, actions, shot order, relationships, ending, dialogue, voice-over, OS, or sound cues. Dialogue must stay verbatim; if any line cannot be verified, stop and ask the user to confirm it. For style-transfer or visual-replacement requests, change only the user-specified visual elements such as people, looks, clothes, scene design, props, visible text treatment, or style while keeping the source content and dialogue unchanged.

Never pass off a locally rendered slideshow, storyboard, or stitched placeholder as a model-generated final video. Final video clips must come from the project-approved video generation method unless the user explicitly asks for a local preview.

## Fixed Gate Sequence

Always follow these gates in order:

1. **Reverse prompt first.** Analyze the provided video and write a complete reverse-prompt result. Include subject, action, scene, lighting, camera, style, quality, dialogue/voice-over, sound, UI/text, and source technical specs.
2. **Wait for reverse-prompt confirmation.** Do not generate assets before the user confirms the reverse prompt.
3. **Generate assets after confirmation.** Create character, scene, and prop assets from the confirmed reverse prompt and the user's asset templates when provided.
4. **Wait for asset confirmation.** Show generated assets and stop. Do not submit video tasks before the user confirms the assets.
5. **Write storyboard/video prompts.** Use confirmed assets and the source's abstract beat rhythm. Do not create storyboard images unless the user explicitly asks for them.
6. **Ask for video model and API options.** Ask which model to use unless the current project already has an explicit user-confirmed model. Confirm any size/ratio compromise when the provider does not support the source ratio.
7. **Generate through the real video API/tool.** Save task IDs, create/status responses, model, duration, size, reference count, prompts, and downloaded files.
8. **Quality-check completion.** Inspect sampled frames and specs before calling a clip done. Verify the requested beats are present, especially the opening, dialogue/action beats, reversal/payoff, and any user-requested extra shot.
9. **Deliver organized files.** Put assets, videos, and project records in the standard project folder structure. Avoid duplicates.

If the user sends a single word such as "确认", advance exactly one gate: reverse prompt -> assets, or assets -> storyboard/video prompt, or model/size confirmation -> API generation.

## Reverse Prompt Requirements

Use the user's current reverse-prompt template when provided. If no template is provided, use `references/reverse-prompt.md`. When the source has dialogue, subtitles, captions, emphasized text, UI text, or any visible words, first fill the mandatory prompt template in `references/dialogue-attribution-template.md`, then write the reverse prompt from that checked attribution.

The reverse prompt must:

- Be based on the source video, not on a guessed story.
- Include visible dialogue, subtitles, VO, OS, and on-screen text as accurately as possible.
- Classify every line with the mandatory attribution template as character dialogue, multiple-character simultaneous dialogue, VO, OS, inner monologue, visible subtitle/emphasis text, or uncertain attribution before writing it into the reverse prompt.
- Never assign visible subtitles, yellow emphasis captions, meme text, UI labels, or punchline text to a character unless mouth movement/audio timing clearly proves the character speaks it.
- If multiple characters say the same line at the same time, write one combined line with all speakers, not repeated separate lines.
- Clearly separate "source video has subtitles/text" from "final remake should not show subtitles/text" when the user requests no text.
- State source technical specs when obtainable: duration, ratio, resolution, fps, audio presence.
- Stop for user confirmation before assets.

If exact dialogue cannot be verified, say so and mark the lines for user confirmation. Do not invent certainty.

## Remake Rules

For the new video:

- Do not invent new content. Do not add plot beats, extra reactions, new props, extra dialogue, explanatory lines, or alternate endings unless the user explicitly requests them.
- Keep all dialogue, VO, OS, and spoken wording exactly the same as the confirmed reverse prompt. Never rewrite, summarize, beautify, localize, or replace dialogue on your own.
- For "style change", "真人写实", "复刻", or "内容/台词保持不变" requests, preserve source timing, shot order, actions, story meaning, and dialogue; only change the explicitly requested visual style and replacement assets.
- Match the source style unless the user changes it. If the source is anime, produce anime-style assets/video. If the source is AI realistic live-action, produce AI realistic live-action assets/video.
- Replace every recognizable concrete visual element requested by the user: character design, wardrobe, location, props, visible text treatment, and distinctive scene dressing. Do not replace wording unless the user explicitly asks for rewritten dialogue.
- Keep only the abstract mechanism: conflict setup, reversal, rhythm, emotional progression, marketing beat, or joke structure.
- Dialogue is allowed unless the user says no dialogue. "No subtitles/text" means no visible words, not silent characters.
- If the user requests no background music, prompts must still allow dialogue and useful environment/action sound unless the user requests mute video.

Use `references/remake-rules.md` for originality boundaries when needed.

## Asset Stage

Use `references/asset-template-prompts.md` when the user provides or expects character/scene/prop templates, four-view, three-view, or six-view assets.

Asset rules:

- Generate each asset as its own file. Do not combine different assets into one contact sheet unless the user explicitly asks for a review sheet.
- A multi-view sheet for a single asset is allowed when requested: one character four-view image, one scene four-view image, one prop six-view image.
- Main recurring characters need character assets; main locations need scene assets; continuity-critical props need prop assets.
- Scene assets must contain no people.
- Asset prompts must include "no subtitles, no text, no logo, no watermark."
- Show assets to the user and wait for confirmation before writing final video prompts or submitting video tasks.

## Storyboard And Video Prompt Stage

Use `references/storyboard-template-workflow.md`.

Prompt rules:

- Use confirmed asset names/IDs and only the new world, not the source's concrete visuals.
- Split long videos into provider-supported clip lengths.
- If the user says not to stitch, deliver independent clips with clear names.
- If the user wants one final film, ask before stitching generated clips; only stitch after all clips come from the real video API/tool.
- Keep prompts under provider limits and include only relevant reference images per clip.
- Include no visible subtitles, no captions, no readable text, no logos, no watermarks, and no background music when requested.

## API Boundary

Use `references/customer-api-workflow.md` when the current project uses image/video APIs.

Never store API keys, service endpoints, bucket names, fixed model-choice rules, user source folders, or output roots in this reusable skill. Treat them as per-project configuration from the user, local files, or environment variables.

Before creating video tasks:

- Confirm the exact video model with the user unless already confirmed in the current project.
- Confirm size/ratio when the source ratio is unsupported by the API.
- Upload approved assets only to a user-approved/public hosting method.
- Save task records so interrupted runs can resume without duplicate submissions.
- If a model, duration, size, or reference count fails, report the non-secret error and ask for fallback unless the user already gave an explicit fallback rule for the current project.
- After any timeout, crash, network error, or interrupted run, inspect saved task records and poll existing task IDs first. Do not assume the task failed just because the local command timed out.
- Do not submit a fallback or replacement video task while an earlier task for the same segment is still `queued` or `in_progress`. Submit a fallback only after the earlier task is definitively `failed`, `cancelled`, rejected at create time, or the user explicitly authorizes a duplicate attempt.
- If duplicate tasks were accidentally created, do not save duplicate clips in the final video folder. Choose the user-priority result, usually the price-priority successful task when the user requested price priority, record all task IDs in `项目资料`, and clearly report what happened.
- Store create/status JSON separately per segment, model, and task ID so status files do not overwrite each other during fallback or resume.

Local processing after API generation is allowed only for delivery hygiene, such as renaming, moving, verifying, transcoding fps/size, or stitching when approved. Record that the visual content came from the API.

## Completion And Correction Rules

Do not mark a video task complete until the generated clip is downloaded, placed in the correct `视频/第N集/` folder, and visually checked.

- Sample frames across the whole clip, including the first second, middle beats, final second, and every requested payoff/reversal shot.
- Verify the final clip contains every user-confirmed required beat. If a required beat is missing, tell the user and either regenerate the affected clip or, when the user explicitly asks, create a short supplemental shot as a separate clip with a clear name.
- A user-requested supplemental shot counts as an explicit allowed content addition. Keep it narrowly scoped to the requested missing shot and do not change prior clips or dialogue.
- Do not say the video is finished if only task creation, queueing, partial progress, or an incomplete/missing-payoff clip exists.
- When normalizing fps, size, container, or filenames after API download, state that only delivery formatting changed and that the visual content came from the API.

## Encoding And Records

Keep project records readable and resumable.

- Write prompts, task records, summaries, CSV files, and Markdown files as UTF-8.
- If terminal output shows garbled Chinese, re-open files with explicit UTF-8 or use a Unicode-safe reader before editing or summarizing them.
- Do not rely on garbled terminal text when extracting dialogue, prompt wording, model names, task IDs, or file names.
- Keep file names clear and localized for user-facing deliverables, while keeping internal IDs stable enough to resume without creating duplicate tasks.

## Local Storage And Cleanup

Keep every generated artifact inside the current project folder or a user-approved output folder.

- Do not save generated images, contact sheets, extracted frames, preview files, QA screenshots, temporary videos, or downloaded API outputs to the Desktop, `C:\`, or other ad hoc local locations unless the user explicitly asks.
- Put review images, contact sheets, extracted frames, source specs, task records, prompt drafts, and QA evidence under `项目资料`, using clear subfolders such as `质检截图`, `frames`, or `video_tasks`.
- Put only final video clips under `视频/第N集/`; do not place preview frames or asset images there.
- Before final delivery, clean up temporary files created outside the project folder. If a temporary file should be preserved, move it into `项目资料` or a user-approved archive folder.
- When disk space is a concern, move confirmed old temporary outputs to a user-approved non-system drive archive instead of deleting user files.

## Delivery Folder Organization

Use one project folder per drama, episode set, or short film. Do not scatter clips or assets directly under a shared delivery root.

Recommended localized structure:

```text
[项目名]/
  人物资产/
  场景资产/
  道具资产/
  视频/
    第1集/
  项目资料/
```

Rules:

- Put character images only in `人物资产`.
- Put scene images only in `场景资产`.
- Put prop images only in `道具资产`.
- Put generated clips in `视频`; if there are episodes, create `视频/第N集/`.
- Put reverse prompts, asset prompts, storyboard prompts, API task records, summaries, rejected versions, and temporary records in `项目资料`.
- Do not duplicate assets or videos.
- If the user asks for a final-only folder, put only final videos there and keep assets/project files elsewhere inside the same project folder.

## Resource Guide

- `references/reverse-prompt.md`: default source reverse-prompt structure.
- `references/dialogue-attribution-template.md`: required dialogue/subtitle attribution guard.
- `references/asset-template-prompts.md`: character, scene, prop, four-view, three-view, and six-view asset prompt rules.
- `references/storyboard-template-workflow.md`: storyboard/video prompt structure, timing, dialogue, and clip rules.
- `references/customer-api-workflow.md`: project API workflow, public media URLs, task creation, polling, downloading, and recovery.
- `references/quality-checklist.md`: final review checklist.
- `references/remake-rules.md`: originality and replacement rules.
- `references/workflow.md`: source deconstruction tables and production package schema.
- `scripts/create_remake_project.py`: optional helper for blank project packages.
