# Prompt Pack

## Character Prompt

```text
[character_tag]: original fictional character, [age range], [body/face description], [hair], [wardrobe], [signature colors], [personality impression], [gesture style], [not based on any real person or source actor]
```

Example:

```text
char_lina_mechanic: original fictional character, woman in her early 30s, square jaw, short black hair with copper clips, oil-stained teal work jacket, practical boots, alert eyes, quick precise hand gestures, not based on any real person or source actor
```

## Scene Prompt

```text
[scene_tag]: [location type], [era/world], [materials], [color palette], [lighting], [weather/atmosphere], [background activity], [distinct from source location]
```

## Prop Prompt

```text
[prop_tag]: [object category], [material], [shape], [scale], [wear/detail], [story function], [distinct from source prop]
```

## Video Shot Prompt

```text
[duration] [aspect ratio]. [character tags] in [scene tag]. [action]. Camera: [movement/framing/lens feel]. Lighting: [lighting]. Mood: [emotion]. Motion details: [micro-actions, background movement]. Style: [chosen visual style]. No source actor likeness, no copied outfits, no original logos, no matching source set design, no duplicated text, no exact source composition.
```

## Dialogue Rewrite Pattern

Replace source dialogue by function:

- Source function: accusation -> New line can be warning, challenge, legal threat, playful dare.
- Source function: proof -> New line can be demonstration, receipt, prophecy, scan result.
- Source function: reveal -> New line can be confession, visual evidence, reversal, public announcement.

Do not paraphrase the original wording. Write new lines from the new world and relationship.

## Audio Prompt

```text
Music: [genre], [tempo], [instrumentation], [emotional progression].
SFX: [specific new-world sounds].
Voice: [performance direction], [pace], [emotion], [accent only if user requests].
Mix: dialogue clear, music ducked under speech, impact accents on beat turns.
```

## Negative Prompt Block

Use when generating images or videos from a source-informed plan:

```text
no original actor likeness, no copied face, no celebrity imitation, no source brand/logo/signage, no source costume, no matching source room layout, no copied prop, no exact shot composition, no duplicated captions, no source video title text
```
