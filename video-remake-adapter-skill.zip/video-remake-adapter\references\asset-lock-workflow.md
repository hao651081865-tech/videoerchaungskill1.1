# Asset Lock Workflow

Use this workflow before generating video clips. It is mandatory when the source or requested output is AI realistic live-action.

## Purpose

Create still-image assets first so the video generation stage has stable references for characters, scenes, props, and key shots. Do not jump from text prompts directly to final video when continuity matters.

## Required Asset Set

### Character Look-Lock Images

Create one base image per main character:

- Neutral full-body or three-quarter portrait.
- Face clearly visible.
- Final hairstyle, age range, body type, wardrobe, color palette, and accessories.
- Realistic live-action still if the source is realistic live-action.
- No source actor likeness.

Create variations when needed:

- Expression sheet: angry, surprised, calm, smiling.
- Angle sheet: front, three-quarter, profile.
- Wardrobe continuity image if clothing details matter.

### Scene Look-Lock Images

Create one base image per location:

- Empty or lightly dressed scene.
- Final time of day, weather, lighting direction, color palette, furniture, background, and spatial layout.
- Match source aspect ratio unless the user requests a new ratio.
- No copied source room layout, set dressing, signage, or distinctive arrangement.

### Prop Look-Lock Images

Create one image per key prop:

- Clean product-style or tabletop image.
- Material, color, shape, scale, wear, and story function visible.
- No copied source prop design.

### Key Storyboard Frames

Create one still image for each major beat or shot:

- Use the approved character, scene, and prop designs.
- Include intended action pose, blocking, lighting, and camera framing.
- Match target video ratio.
- Use these frames as image references for video generation.

## Asset Index Columns

Use `assets-index.csv` with these columns:

- `asset_id`
- `asset_type`
- `file_name`
- `description`
- `prompt`
- `negative_prompt`
- `reference_role`
- `status`
- `notes`

## Naming

Use stable names:

- `char_<name>_looklock_01`
- `char_<name>_expression_<emotion>`
- `scene_<name>_looklock_01`
- `prop_<name>_looklock_01`
- `keyframe_<shot_id>_<short_beat>`

## Prompt Pattern

```text
Realistic live-action still image, [asset subject], [specific visual details], [lighting], [camera/lens], [target aspect ratio], cinematic realism, no text, no subtitles, no logos, no source actor likeness, no copied source set design.
```

When the user provides the 招商/制作提示词流程 templates, do not use only this generic pattern. First map the source analysis into the customer template structures in `asset-template-prompts.md`, then generate:

- Character model prompts and character four-view images.
- Scene model prompts and scene four-view images.
- Prop model prompts and prop six-view images.
- Key storyboard frames after the model assets are available.

For source-video remakes, keep the target ratio aligned with the source video unless the user explicitly changes it.

## Approval Gate

Before video generation:

1. Confirm every main character has a look-lock image.
2. Confirm every main scene has a look-lock image.
3. Confirm every critical prop has a look-lock image.
4. Confirm key storyboard frames exist for every generated clip.
5. Confirm assets match the source style and target ratio.
6. Use approved images as references when generating video clips.

If assets are missing, stop and create them before video generation.
