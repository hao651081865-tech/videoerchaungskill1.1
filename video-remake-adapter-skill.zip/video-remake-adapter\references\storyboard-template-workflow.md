# Storyboard And Video Prompt Workflow

Use this reference only after:

1. The source reverse prompt is confirmed.
2. Character, scene, and prop assets are generated.
3. The user confirms those assets.

Do not create storyboard images unless explicitly requested. When the user says text-to-video is enough, write text storyboard/video prompts only.

## Segment Template

Each generated clip should be a self-contained segment:

```text
## 第1集 第1场 分镜X_[短内容名]

【无显示字幕，无显示台词，无显示字符】
【出场人物：@角色A，@角色B】
【场景：@场景名】
【参考资产：资产文件1；资产文件2；资产文件3】
【戏剧任务：[本段剧情功能]】

1 时长 00:00-00:XX
核心画面提示词：[景别、机位、角色站位、动作、表情、环境、光影、运镜、质感]
对话/音效：[角色台词或具体环境音/动作音；无台词则写“无”]

2 时长 00:XX-00:XX
核心画面提示词：[具体画面]
对话/音效：[具体声音]

【画面要求】[风格、比例、清晰度、光影、禁止字幕/文字/logo/水印]
【声音要求】[无BGM/仅对白/环境声/动作音效]
```

Do not use vague phrases such as "same as above." Every shot must contain camera-capturable content.

## Timing Rules

- Each clip starts timing from `00:00`; do not accumulate timestamps across clips.
- Use provider-supported durations such as 5, 10, or 15 seconds when applicable.
- Put 3-8 shots in one video-generation segment.
- Calm dialogue: about 4 Chinese characters per second.
- Anxious dialogue: about 5 Chinese characters per second.
- Split long dialogue across shots or use listener reactions while the line continues.
- Bind gestures to spoken lines instead of adding empty action time.

## Prompt Rules

- Use confirmed character, scene, and prop asset names or IDs.
- Describe only the new world; do not mention source actors, source character names, source set design, source text, or original brands.
- Keep the source rhythm and abstract reversal/beat structure.
- Match source ratio unless the user confirms an API-supported alternative.
- Include "no subtitles, no visible text, no logos, no watermarks" in every segment.
- If no background music is requested, say "no BGM" and allow only dialogue, environment sound, and necessary action sound.
- Dialogue is allowed unless the user asks for mute/no dialogue.

## Clip Delivery

- If the user says not to stitch, deliver each clip independently with clear names.
- If the user wants a single final video, ask before stitching. Only stitch generated clips after they have all been downloaded from the approved video API/tool.
- Save storyboard prompts in project files before submitting video tasks.
- Save task IDs and status records so interrupted runs can resume without duplicate submissions.
