# Quality Checklist

## Originality

- Every character has a new fictional identity and visual signature.
- Every scene is a different place with different visual grammar.
- Every key prop is replaced with a different object.
- Dialogue is newly written and not a paraphrase.
- Captions and on-screen text are new.
- Prompts do not mention original names, actors, brands, titles, or exact visuals.
- No single frame reads as a close copy of the source.

## Story Clarity

- The hook is clear in the first 1-3 seconds for short-form video.
- The central conflict or promise is understandable without the source.
- The emotional turn lands visibly.
- The ending resolves, reverses, teases, or converts according to the brief.

## Production Readiness

- Character look-lock images exist for every main character before video generation.
- Scene look-lock images exist for every main location before video generation.
- Prop look-lock images exist for every story-critical prop before video generation.
- Key storyboard frames exist for every major video clip before video generation.
- Approved image assets are used as references for video generation where the tool supports image references.
- Character tags are consistent across prompts.
- Scene tags are consistent across prompts.
- Duration totals match target runtime.
- Aspect ratio matches platform.
- Camera directions are feasible for the chosen generation or editing tool.
- Negative prompts are attached to high-risk shots.
- If the source is AI realistic live-action, the final video is also AI realistic live-action.
- A local storyboard animation, drawn schematic, animatic, or slideshow is not accepted as the final delivery unless the user explicitly asks for that style.
- If the chosen video model only supports fixed clip lengths such as 5, 10, or 15 seconds, split the plan into supported segments and stitch the generated clips.

## Continuity

- Wardrobe, hair, and props remain consistent unless intentionally changed.
- Screen direction and action logic remain coherent.
- Time of day and lighting do not jump accidentally.
- Voice, music, and sound effects match the new world.

## Final Handoff

Include a concise summary:

- New concept.
- What was preserved at an abstract level.
- What was changed concretely.
- Any assumptions made because the source video was unavailable or unclear.
- Remaining production steps.
