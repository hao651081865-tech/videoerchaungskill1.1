# Asset Template Prompts

Use this reference after the user confirms the reverse prompt and asks to generate assets.

## Core Rules

- Derive asset prompts from the confirmed reverse prompt.
- Keep the final style aligned with the source unless the user changes it.
- Replace source-specific character designs, locations, props, outfits, brands, visible text, and exact scene dressing.
- Generate each asset separately. Do not combine different assets into one review image unless explicitly requested.
- A multi-view sheet is one asset file when it describes only one character, one scene, or one prop.
- Do not create storyboard images unless the user explicitly asks for them.
- Every asset prompt must include: no subtitles, no text, no logo, no watermark.

## Asset Selection

Create:

- Main character assets for recurring characters.
- Scene assets for each main location and important time-of-day variant.
- Prop assets for hand-held objects, accessories, documents, phones, symbolic objects, or objects that affect continuity.

Ignore one-frame extras unless they are story-critical.

## Character Four-View Prompt Structure

Use one file per character.

```text
人物名称：[姓名或角色标签]，身份：[身份]，具体造型时期：[使用场景]，角色级别：[主角/配角]。
出现集数：第1集。
[目标风格]，白色背景，同一角色四个视图完全一致。
人物：[年龄段、性别、地域气质、身高、体型、整体气质]。
头部：[发型、发色、发质、五官、妆容、眼镜/发饰/耳饰等配饰]。
身体：[服装颜色、款式、剪裁、纹理、材质、饰品、佩戴位置]。
脚部：[鞋子颜色、款式、材质、鞋底/跟高特征]。
人物四视图：画面从左到右依次为面部特写、正面全身、侧面全身、背面全身。五官、身高、体型、服装、配饰、光影、材质100%一致。标准中立自然站姿，全身完整入镜，每个视图有清楚分隔线，但不要任何文字标签。
无字幕，无文字，无logo，无水印，目标比例/分辨率：[按项目需要]。
负面要求：不复制源视频角色脸、服装、发型、配饰或可识别设计。
```

If the user requests three-view instead of four-view, use front full body, side full body, and back full body only.

## Scene Four-View Prompt Structure

Use one file per location. Scene assets must have no people.

```text
场景名称：[地点名]，时间段：[白天/夜晚/黄昏]，氛围：[情绪]，主要/次要场景，出现集数：第1集。
[目标风格]，室内/室外场景四视图，同一空间，所有视角统一光影，场景客观事实一致，每个视图有明显分割线，不出现提示文字。
具体场景：[完整环境描述]。画面中无任何人物。
包含全景视图、侧面方向、背面方向、远景层视图。房间必须有门和窗；家具比例真实；材质清晰。
远景层：[远景内容]；背景层：[背景内容]；中景层：[中景内容]；前景层：[前景内容]。
主要视觉引导线：[引导线]；画面兴趣点：[兴趣点]；主色调：[主色调]；辅助色：[辅助色]。
无字幕，无文字，无logo，无水印，目标比例/分辨率：[按项目需要]。
负面要求：不复制源视频房间布局、家具组合、墙面装饰、品牌标识或可读文字。
```

## Prop Six-View Prompt Structure

Use one file per prop.

```text
道具名称：[道具名]，归属角色/场景：[归属]，状态：[佩戴/手持/摆放/使用中]，主要/次要道具，出现集数：第1集。
[目标风格]，纯色背景，同一件道具六个视角完全一致。
道具描述：[尺寸感、颜色、材质、工艺、新旧程度、结构、佩戴或使用方式、剧情功能]。
道具模型六视图：正视图展示正面主体结构与主要细节；背视图展示背面结构、卡扣或接口；左视图展示左侧轮廓与侧面比例；右视图展示右侧轮廓与表面纹理；俯视图展示顶部形状与整体轮廓；仰视图展示底部结构与隐藏细节。每个视图都有明显分割线，但不要任何文字标签。
无字幕，无文字，无logo，无水印，目标比例/分辨率：[按项目需要]。
负面要求：不复制源视频道具造型、品牌标识或可读文字。
```

## Approval Gate

After asset images are generated:

1. Show each asset separately.
2. List the saved paths.
3. Ask the user to confirm the assets.
4. Do not write final video prompts or submit video tasks until confirmed.
