# Dialogue Attribution Template

Use this template during reverse-prompt work whenever the source video contains speech, subtitles, emphasized captions, UI text, or on-screen words.

## Mandatory Prompt Template

Use this Chinese template before writing any reverse prompt. Fill it from the source video first, then use the checked result in the final reverse prompt.

```text
【对白/字幕归因检查提示词】

请先逐镜头检查源视频中的所有声音和画面文字，不要直接把字幕当成角色台词。

必须按以下分类输出：

1. 角色对白：
   - 只有当画面中角色口型、说话时机、表情动作都能对应时，才写成角色对白。
   - 格式：{角色名}（具体表情/动作）：{一字不差的台词}

2. 多人同说：
   - 如果两个或多个角色同一时间说同一句话，必须合并成一行，不能拆成某个角色重复说。
   - 格式：{角色A、角色B}（同时/异口同声，具体表情/动作）：{一字不差的台词}

3. 画外音 VO：
   - 没有对应口型、像旁白或解说的声音，写成 VO。
   - 格式：{角色名或旁白} VO：{台词}

4. 画外说话 OS：
   - 说话人不在画面里，但属于场内人物说话，写成 OS。
   - 格式：{角色名} OS：{台词}

5. 内心 OS：
   - 没有开口动作，但表达人物内心想法，写成内心 OS。
   - 格式：{角色名} OS：{内心的话}

6. 画面字幕/强调字：
   - 白色字幕、黄色强调字、梗字幕、弹幕、UI字、标题字、说明字，不能默认写成角色台词。
   - 只有明确听到角色说出、且口型对应，才允许归入角色对白。
   - 格式：【画面字幕/强调字】{颜色/位置/用途}：{画面文字}

7. 不确定归因：
   - 听不清、口型对不上、字幕像强调文案但可能有人声时，必须标为不确定，等待用户确认。
   - 格式：【不确定归因】{时间点}：{听到/看到的内容}，需要用户确认。

输出前必须自查：
- 有没有把黄色强调字、梗字幕、UI文字误写成角色台词？
- 有没有把两个人同时说的一句话拆成某一个人重复说？
- 有没有把字幕内容当成已确认音频？
- 有没有把不确定台词写得很肯定？

通过检查后，再进入正式反推提示词。正式反推中必须保留分类结果：
- 角色说的话写在角色名后面。
- 两人同时说的话写成“角色A、角色B（同时/异口同声）：台词”。
- 画面字幕/强调字单独写成“【画面字幕/强调字】”，不归给任何角色。
- 不确定内容必须向用户确认，不能自行猜。
```

## Core Rule

Do not treat visible text as spoken dialogue by default. First classify every line as one of these:

- `对白`: a character visibly speaks the line, with mouth movement, timing, and shot context supporting the attribution.
- `多人同说`: two or more characters visibly say the same line at the same time.
- `VO`: off-screen narration or voice-over not tied to visible mouth movement.
- `OS`: off-screen character speech, where the speaker is outside the frame.
- `内心 OS`: inner monologue, usually not tied to visible mouth movement.
- `画面字幕/强调字`: visible captions, subtitles, labels, or emphasis text that may summarize or punch up the scene and must not be assigned to a character unless clearly spoken.
- `不确定`: unclear audio/text attribution requiring user confirmation.

## Required Reverse-Prompt Format

Use this structure for every dialogue/text beat:

```text
{角色名}（具体表情或动作）：{确认是角色说出的台词}

{角色A、角色B}（同时/异口同声，具体表情或动作）：{两人同时说出的台词}

{角色名} VO：{画外音台词}

{角色名} OS：{画外说话}

【画面字幕/强调字】{字幕颜色/位置/用途}：{画面上出现的文字}

【不确定归因】{时间点}：{听到或看到的内容}，需要用户确认是否为角色台词。
```

## Attribution Checklist

Before presenting a reverse prompt:

1. Compare mouth movement, shot timing, and subtitle timing.
2. If a visible subtitle appears while no character mouth movement matches it, classify it as `画面字幕/强调字`, not dialogue.
3. If two characters react and speak the same short line together, write one combined line with both character names, not repeated separate lines.
4. Do not convert yellow emphasis text, meme captions, UI labels, or punchline captions into dialogue.
5. If exact audio cannot be verified, mark it as `不确定` and ask the user to confirm.
6. In remake/video prompts, include visible source subtitles only as source analysis. When the user requests no text, final video prompts must say no visible subtitles, captions, readable text, logos, or watermarks.
