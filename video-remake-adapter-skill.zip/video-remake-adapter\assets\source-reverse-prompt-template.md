# Source Reverse Prompt

## Complete Video Prompt

[Subject]. [Action]. [Scene and atmosphere]. [Lighting]. [Camera movement and framing]. [Visual style and color]. [Quality/render settings].

## Structured Breakdown

### Subject

- People:
- Objects/props:
- Wardrobe/materials:
- Expressions/identifiers:

### Action

- Motion:
- Interaction:
- Timing/speed:
- Continuity:

### Scene

- Environment:
- Atmosphere:
- Time setting:
- Background/spatial layout:

### Lighting

- Type:
- Intensity:
- Direction:
- Color/contrast:

### Camera

- Shot size:
- Angle:
- Movement:
- Lens/focus:

### Style

- Visual style:
- Tone/palette:
- Texture/mood:

### Quality

- Resolution:
- Frame rate:
- Aspect ratio:
- Motion blur/grain/VFX:
