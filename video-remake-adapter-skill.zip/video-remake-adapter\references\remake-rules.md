# Remake Rules

## Preserve Only Abstract Functions

Allowed to preserve:

- High-level story arc.
- Hook position.
- Beat order.
- Emotional contrast.
- Information sequence.
- Camera intent.
- Approximate pacing.
- Conversion or persuasion mechanism.

Not allowed to preserve:

- Exact actor likenesses or character designs.
- Names, brands, logos, uniforms, distinctive costumes, or makeup.
- Exact scene layout, set dressing, signage, or color identity.
- Exact prop design or iconic object combinations.
- Exact dialogue, catchphrases, captions, jokes, or slogan.
- Exact shot composition, blocking, or choreography.
- Original soundtrack, sound marks, or voice impression.

## Replacement Standards

Change each concrete element across at least three dimensions:

- Category: office becomes market, palace, space station, clinic, classroom, rural yard.
- Visual: materials, color, shape, scale, density, era.
- Social meaning: boss/employee becomes master/apprentice, healer/patient, captain/recruit, vendor/customer.
- Action mechanics: signing a paper becomes stamping clay, scanning a wristband, tying a red string, testing a device.
- Sound world: corporate bed becomes folk percussion, cyber pulses, chamber strings, street ambience.

## Similarity Risk Levels

High risk:

- Same scene type plus same character relationship plus same key prop.
- Same punchline or revelation.
- Same product placement path.
- Same composition at the same timestamp.

Medium risk:

- Same story arc but changed setting and characters.
- Same camera intent with clearly different staging.

Low risk:

- Same emotional function only.
- Same genre convention with original characters, setting, props, and dialogue.

## Adaptation Decision Rule

If a viewer could identify the original video from a single remake frame, change more. If a viewer could identify the original only from the abstract sequence of beats, the transformation is usually strong enough.

## Notes for Reference Videos Featuring Real People

Do not generate or request recognizable replacements that imitate the source person's face, voice, body, or signature mannerisms. Create new fictional people with distinct age range, styling, posture, and voice direction.
