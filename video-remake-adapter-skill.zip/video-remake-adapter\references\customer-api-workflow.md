# Customer API Workflow

Use this reference only when the current project provides image or video generation APIs.

Keep all API details as per-project configuration. Do not write API keys, fixed model-choice rules, service endpoints, bucket names, source folders, or output roots into the reusable skill.

## Configuration Rules

- Read credentials from the current project context, local private files, or process environment.
- Never print, repeat, log, or save API keys in prompts, final answers, screenshots, or skill files.
- Ask the user which video model to use unless the current project already has an explicit confirmed model.
- If the user gives a model-selection rule, follow it for that project only.
- If an API rejects a model, size, duration, or reference count, report the exact non-secret error and ask for a fallback unless the user already gave a fallback rule for this project.

## Image Generation

Use the project's configured image API to create approved-stage assets:

- Character multi-view or look-lock images.
- Scene multi-view or look-lock images.
- Prop multi-view or look-lock images.
- Storyboard images only when explicitly requested.

Save each asset into the correct project folder and record:

- Asset ID.
- Asset type.
- Prompt.
- Local path.
- Approval status.

## Public Media URLs

Video APIs often require public HTTPS URLs for reference images.

Before creating video tasks:

1. Upload only user-approved assets.
2. Confirm each URL can be reached without login.
3. Use only confirmed public URLs in `media_urls` or the provider's equivalent reference field.
4. Save the local-path-to-public-URL mapping in project files.

If no public hosting method is available, stop and ask the user for an upload method.

## Video Task Creation

Use the user-confirmed video model and current project API documentation.

Common fields may include:

- `model`: user-confirmed video model ID.
- `prompt`: one segment prompt.
- `seconds` or `duration`: provider-supported clip length.
- `size`, `ratio`, or `aspect_ratio`: source ratio or user-confirmed API-supported alternative.
- `media_urls`: public HTTPS reference images/videos/audio.

Do not assume fields are universal. Check the project API documentation before submitting.

## Resume And Error Handling

Before creating a task, check whether the same segment already has a saved create response with a task ID. If it does, poll that existing task instead of creating a duplicate.

After creating a task:

1. Save the create response, task ID, model, prompt, duration, size, reference count, and output target.
2. Poll at a reasonable interval.
3. Save status responses.
4. Download the video when completed.
5. If polling times out, retry polling the same task ID.
6. If a task fails, record the non-secret error and revise only the relevant prompt/reference/model choice.

## Delivery Rules

- Put generated videos in the current project's `视频` folder, with `第N集` subfolders when relevant.
- Do not duplicate videos.
- Do not place preview frames or asset images inside a final-only video folder unless the user asks.
- If the provider returns the wrong fps or dimensions, local transcode/resize is allowed only as delivery normalization after the API-generated video is downloaded. Record that visual content came from the API.
- If the user asks for no background music and no text, ensure prompts request no subtitles, no captions, no readable text, no logos, no watermarks, and no BGM.
