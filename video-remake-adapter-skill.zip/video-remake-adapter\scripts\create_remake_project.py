#!/usr/bin/env python3
"""Create a structured video remake project folder."""

from __future__ import annotations

import argparse
import csv
import json
import textwrap
from datetime import datetime
from pathlib import Path


SOURCE_ANALYSIS_HEADERS = [
    "id",
    "source_time",
    "source_event",
    "story_function",
    "character_function",
    "scene_function",
    "prop_function",
    "camera_intent",
    "emotion",
    "audio_function",
    "must_not_copy",
]

REPLACEMENT_HEADERS = [
    "source_element",
    "source_role",
    "replace_with",
    "new_visual_signature",
    "what_to_preserve",
    "what_to_avoid",
    "prompt_token",
]

SHOTLIST_HEADERS = [
    "shot_id",
    "duration_sec",
    "new_beat",
    "new_character_tags",
    "new_scene_tag",
    "new_prop_tags",
    "action",
    "camera",
    "lighting_color",
    "dialogue_or_caption",
    "audio",
    "video_prompt",
    "negative_prompt",
    "qc_notes",
]

VIDEO_PROMPT_HEADERS = [
    "shot_id",
    "tool",
    "prompt",
    "negative_prompt",
    "duration_sec",
    "aspect_ratio",
    "seed_or_reference",
    "status",
]

ASSET_INDEX_HEADERS = [
    "asset_id",
    "asset_type",
    "file_name",
    "description",
    "prompt",
    "negative_prompt",
    "reference_role",
    "status",
    "notes",
]

STORYBOARD_HEADERS = [
    "shot_id",
    "duration_sec",
    "screen_content",
    "subject",
    "action",
    "environment",
    "lighting",
    "camera",
    "empty_or_insert_shot",
    "emotion_rhythm",
    "quality",
]

SOURCE_REVERSE_PROMPT_HEADERS = [
    "shot_id",
    "timestamp",
    "subject",
    "action",
    "scene",
    "lighting",
    "camera",
    "style",
    "quality",
    "complete_prompt",
]


def write_text(path: Path, text: str) -> None:
    path.write_text(textwrap.dedent(text).strip() + "\n", encoding="utf-8")


def write_csv(path: Path, headers: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        csv.writer(f).writerow(headers)


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a video remake project folder.")
    parser.add_argument("project_name", help="Folder name for the remake project.")
    parser.add_argument("--output", default=".", help="Parent output directory.")
    parser.add_argument("--source-video", default="", help="Path or URL of the source video.")
    parser.add_argument("--target-duration", default="", help="Target duration, such as 30s or 1m20s.")
    parser.add_argument("--aspect-ratio", default="9:16", help="Target aspect ratio.")
    parser.add_argument("--style", default="", help="Target visual style.")
    args = parser.parse_args()

    root = Path(args.output).expanduser().resolve() / args.project_name
    folders = [
        "00_brief",
        "01_source_analysis",
        "02_remake_design",
        "03_assets",
        "04_prompts",
        "05_editing",
        "06_qc",
        "07_outputs",
    ]
    for folder in folders:
        (root / folder).mkdir(parents=True, exist_ok=True)

    write_text(
        root / "00_brief" / "remake-brief.md",
        f"""
        # Remake Brief

        ## Source

        - Source video: {args.source_video}
        - Target duration: {args.target_duration}
        - Aspect ratio: {args.aspect_ratio}
        - Style: {args.style}

        ## New Concept

        - New title:
        - Genre:
        - Audience:
        - Hook:
        - Emotional arc:

        ## Originality Boundary

        - Preserve only:
        - Replace completely:
        - Must avoid:
        """,
    )

    write_csv(root / "01_source_analysis" / "source-analysis.csv", SOURCE_ANALYSIS_HEADERS)
    write_csv(root / "01_source_analysis" / "source-reverse-prompts.csv", SOURCE_REVERSE_PROMPT_HEADERS)
    write_csv(root / "02_remake_design" / "replacement-matrix.csv", REPLACEMENT_HEADERS)
    write_csv(root / "02_remake_design" / "shotlist.csv", SHOTLIST_HEADERS)
    write_csv(root / "03_assets" / "assets-index.csv", ASSET_INDEX_HEADERS)
    write_csv(root / "04_prompts" / "storyboard-animation-shots.csv", STORYBOARD_HEADERS)
    write_csv(root / "04_prompts" / "video-prompts.csv", VIDEO_PROMPT_HEADERS)

    write_text(
        root / "01_source_analysis" / "source-reverse-prompt.md",
        """
        # Source Reverse Prompt

        ## Complete Video Prompt

        [Subject]. [Action]. [Scene and atmosphere]. [Lighting]. [Camera movement and framing]. [Visual style and color]. [Quality/render settings].

        ## Structured Breakdown

        ### Subject

        - People:
        - Objects/props:
        - Wardrobe/materials:
        - Expressions/identifiers:

        ### Action

        - Motion:
        - Interaction:
        - Timing/speed:
        - Continuity:

        ### Scene

        - Environment:
        - Atmosphere:
        - Time setting:
        - Background/spatial layout:

        ### Lighting

        - Type:
        - Intensity:
        - Direction:
        - Color/contrast:

        ### Camera

        - Shot size:
        - Angle:
        - Movement:
        - Lens/focus:

        ### Style

        - Visual style:
        - Tone/palette:
        - Texture/mood:

        ### Quality

        - Resolution:
        - Frame rate:
        - Aspect ratio:
        - Motion blur/grain/VFX:
        """,
    )
    write_text(
        root / "02_remake_design" / "character-bible.md",
        """
        # Character Bible

        For each character, define: tag, role function, new identity, visual signature, wardrobe, behavior, voice, continuity notes, negative constraints.
        """,
    )
    write_text(
        root / "02_remake_design" / "scene-bible.md",
        """
        # Scene Bible

        For each scene, define: tag, story function, new location, era/world, materials, color, lighting, background activity, negative constraints.
        """,
    )
    write_text(
        root / "02_remake_design" / "prop-bible.md",
        """
        # Prop Bible

        For each prop, define: tag, source function, new object, material, shape, usage, symbolism, negative constraints.
        """,
    )
    write_text(
        root / "02_remake_design" / "script.md",
        """
        # New Script

        Write only the new version. Do not paraphrase source dialogue.
        """,
    )
    write_text(
        root / "03_assets" / "asset-plan.md",
        """
        # Asset Plan

        Create image assets before video generation.

        ## Character Look-Lock Images

        - Main character 1:
        - Main character 2:

        ## Scene Look-Lock Images

        - Main scene:

        ## Prop Look-Lock Images

        - Critical prop 1:
        - Critical prop 2:

        ## Key Storyboard Frames

        - One still frame per major shot or generated clip.

        ## Approval Gate

        Do not generate video clips until these images are created and approved for continuity.
        """,
    )
    write_text(
        root / "04_prompts" / "storyboard-animation-prompt.md",
        """
        # Storyboard Animation Prompt

        生成真人写实风格，根据以下内容自我理解后生成相应的分镜动画，合理的构建分镜，合理的动作，合理的运镜，合理的环境渲染，发散你的想象力。不要字幕，电影级分镜理解，合理的空镜头运用，横屏模式： 时间：白天 地点：客厅内 画面内容：

        [Paste source reverse-prompt content here]

        ## Shot Expansion

        | 镜头编号 | 时长 | 画面内容 | 人物/主体 | 动作 | 场景环境 | 光影 | 运镜 | 空镜头/插入镜头 | 情绪节奏 | 画质参数 |
        |---|---:|---|---|---|---|---|---|---|---|---|
        """,
    )
    write_text(
        root / "05_editing" / "audio-plan.md",
        """
        # Audio Plan

        Define voice, music, sound effects, pacing, transitions, and mix notes.
        """,
    )
    write_text(
        root / "05_editing" / "edit-plan.md",
        """
        # Edit Plan

        Define assembly order, shot durations, captions, transitions, speed changes, and platform export notes.
        """,
    )
    write_text(
        root / "06_qc" / "qc-checklist.md",
        """
        # QC Checklist

        - All characters replaced.
        - All scenes replaced.
        - All props replaced.
        - Dialogue newly written.
        - No source logos, names, faces, outfits, set layouts, or exact compositions.
        - Duration and aspect ratio match target.
        - Character and scene continuity are consistent.
        """,
    )

    manifest = {
        "project_name": args.project_name,
        "source_video": args.source_video,
        "target_duration": args.target_duration,
        "aspect_ratio": args.aspect_ratio,
        "style": args.style,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "skill": "video-remake-adapter",
    }
    write_text(root / "manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))

    print(root)


if __name__ == "__main__":
    main()
